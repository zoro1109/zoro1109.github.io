% Predicate to start the game
play :- my_turn([]).

% Predicate to handle the player's turn
my_turn(Game) :-
    valid_moves(ValidMoves, Game, x), % Find valid moves for player x
    any_valid_moves(ValidMoves, Game). % Proceed with any valid moves

% Predicate to handle any valid moves
any_valid_moves([], _) :-
    write('It is a tie'), nl. % If no valid moves left, it's a tie

any_valid_moves([_|_], Game) :-
    findall(NextMove, game_analysis(x, Game, NextMove), MyMoves), % Analyze possible moves for player x
    do_a_decision(MyMoves, Game). % Make a decision for player x

% Predicate to make a decision for player x
do_a_decision(MyMoves, Game) :-
    not(MyMoves = []), % If there are possible moves
    length(MyMoves, MaxMove), % Get the maximum number of moves
    random(0, MaxMove, ChosenMove), % Choose a random move
    nth0(ChosenMove, MyMoves, X), % Get the chosen move
    NextGame = [X | Game], % Update the game with the chosen move
    print_game(NextGame), % Print the updated game
    (victory_condition(x, NextGame) -> % Check if player x won
        (write('I won. You lose.'), nl) % Print the victory message
    ;   your_turn(NextGame), !). % Proceed with the opponent's turn

% Predicate to handle the opponent's turn
your_turn(Game) :-
    valid_moves(ValidMoves, Game, o), % Find valid moves for player o
    (ValidMoves = [] ->
        (write('It is a tie'), nl) % If no valid moves left, it's a tie
    ;   (write('Available moves:'), write(ValidMoves), nl, % Print available moves
        ask_move(Y, ValidMoves), % Ask for opponent's move
        NextGame = [Y | Game], % Update the game with opponent's move
        (victory_condition(o, NextGame) -> % Check if opponent won
            (write('I lose. You win.'), nl) % Print the victory message
        ;   my_turn(NextGame), !))). % Proceed with player x's turn

% Predicate to ask for opponent's move
ask_move(Move, ValidMoves) :-
    write('Give your move:'), nl, % Prompt for move input
    read(Move), member(Move, ValidMoves), !. % Read and validate the move

ask_move(Y, ValidMoves) :-
    write('Not a valid move'), nl, % Print error message for invalid move
    ask_move(Y, ValidMoves). % Ask for move again

% Predicate to print the game
print_game(Game) :-
    plot_row(0, Game), plot_row(1, Game), plot_row(2, Game).

% Predicate to plot a row of the game
plot_row(Y, Game) :-
    plot(Game, 0, Y), plot(Game, 1, Y), plot(Game, 2, Y), nl.

% Predicate to plot a cell of the game
plot(Game, X, Y) :-
    (member(move(P, X, Y), Game), ground(P)) -> write(P) ; write('.').

% Predicate to analyze the game state
game_analysis(_, Game, _) :-
    victory_condition(Winner, Game), % Check if there's a winner
    Winner = x. % We do not want to lose

game_analysis(Turn, Game, NextMove) :-
    not(victory_condition(_, Game)), % If no winner yet
    game_analysis_continue(Turn, Game, NextMove). % Continue game analysis

% Predicate to continue game analysis
game_analysis_continue(Turn, Game, NextMove) :-
    valid_moves(Moves, Game, Turn), % Find valid moves for the current player
    game_analysis_search(Moves, Turn, Game, NextMove). % Search for the next move

% Predicate to search for the next move
game_analysis_search([], o, _, _) :- !. % Tie on opponent's turn
game_analysis_search([], x, _, _) :- !. % Tie on our turn
game_analysis_search([X|Z], o, Game, NextMove) :- % Whatever opponent does,
    NextGame = [X | Game], % we desire not to lose
    game_analysis_search(Z, o, Game, NextMove),
    game_analysis(x, NextGame, _), !.
game_analysis_search(Moves, x, Game, NextMove) :-
    game_analysis_search_x(Moves, Game, NextMove).

game_analysis_search_x([X|_], Game, X) :-
    NextGame = [X | Game],
    game_analysis(o, NextGame, _).
game_analysis_search_x([_|Z], Game, NextMove) :-
    game_analysis_search_x(Z, Game, NextMove).

% Predicate to define a valid game
valid_game(Turn, Game, LastGame, Result) :-
    victory_condition(Winner, Game) -> % Check if there's a winner
        (Game = LastGame, Result = win(Winner)) % If it's the last game, return the winner
    ;   valid_continuing_game(Turn, Game, LastGame, Result). % Otherwise, continue the game

% Predicate to define a valid continuing game
valid_continuing_game(Turn, Game, LastGame, Result) :-
    valid_moves(Moves, Game, Turn), % Find valid moves for the current player
    tie_or_next_game(Moves, Turn, Game, LastGame, Result). % Check if it's a tie or proceed with next game

% Predicate to check if it's a tie or proceed with next game
tie_or_next_game([], _, Game, Game, tie). % If no valid moves left, it's a tie
tie_or_next_game(Moves, Turn, Game, LastGame, Result) :-
    valid_gameplay_move(Moves, NextGame, Game), % Make a valid gameplay move
    opponent(Turn, NextTurn), % Determine the opponent's turn
    valid_game(NextTurn, NextGame, LastGame, Result). % Check the validity of the next game

% Predicate to check victory conditions for tic tac toe
victory(P, Game, Begin) :-
    valid_gameplay(Game, Begin), % Check if the game is valid
    victory_condition(P, Game). % Check if there's a winner

% Predicate to check victory conditions
victory_condition(P, Game) :-
    (X = 0; X = 1; X = 2),
    member(move(P, X, 0), Game),
    member(move(P, X, 1), Game),
    member(move(P, X, 2), Game).
victory_condition(P, Game) :-
    (Y = 0; Y = 1; Y = 2),
    member(move(P, 0, Y), Game),
    member(move(P, 1, Y), Game),
    member(move(P, 2, Y), Game).
victory_condition(P, Game) :-
    member(move(P, 0, 2), Game),
    member(move(P, 1, 1), Game),
    member(move(P, 2, 0), Game).
victory_condition(P, Game) :-
    member(move(P, 0, 0), Game),
    member(move(P, 1, 1), Game),
    member(move(P, 2, 2), Game).

% Predicate to define valid gameplay
valid_gameplay(Start, Start). % The game starts
valid_gameplay(Game, Start) :- % Continue the game
    valid_gameplay(PreviousGame, Start), % Previous game is valid
    valid_moves(Moves, PreviousGame, _), % Find valid moves for the current player
    valid_gameplay_move(Moves, Game, PreviousGame). % Proceed with next game

% Predicate to define a valid gameplay move
valid_gameplay_move([X|_], [X|PreviousGame], PreviousGame). % Make a valid gameplay move
valid_gameplay_move([_|Z], Game, PreviousGame) :- % If not a valid move
    valid_gameplay_move(Z, Game, PreviousGame). % Try again

% Predicate to define valid moves
valid_moves(Moves, Game, Turn) :-
    valid_moves_column(0, M1, [], Game, Turn), % Find valid moves for each column
    valid_moves_column(1, M2, M1, Game, Turn),
    valid_moves_column(2, Moves, M2, Game, Turn).

% Predicate to define valid moves for a column
valid_moves_column(X, M3, M0, Game, Turn) :-
    valid_moves_cell(X, 0, M1, M0, Game, Turn), % Find valid moves for each cell in a column
    valid_moves_cell(X, 1, M2, M1, Game, Turn),
    valid_moves_cell(X, 2, M3, M2, Game, Turn).

% Predicate to define valid moves for a cell
valid_moves_cell(X, Y, M1, M0, Game, Turn) :-
    (member(move(_, X, Y), Game) -> M0 = M1 ; M1 = [move(Turn, X, Y) | M0]). % Check if the cell is occupied or add a valid move

% Predicate to determine the opponent
opponent(x, o).
opponent(o, x).
