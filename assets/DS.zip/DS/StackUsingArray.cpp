#include <iostream>
using namespace std;

class Stack {
	int top;
	
	public:
	int array[100];
	//Maximum size of Stack is 100
	
	//Constructor
	
	Stack(){top = -1;};
	
	void push(int x);
	int pop();
	void isEmpty();
	void Display();
};

// Two colons (::) are used in C++ as a scope resolution operator

void Stack::push(int x){
	if(top >= 100){
		cout <<"Stack overflow \n";
		
	}
	else {
		array[++top]=x;
		cout <<"Pushed"<<x<<"\n";
	}
}
int Stack::pop(){
	if(top<0){
		cout << "Stack Underflow \n";
		return 0;
	}
	else {
		int d = array[top--];
		return d;
	}
}

void Stack::isEmpty(){
	if(top<0){
		cout << "Stack is Empty \n";
	}
	else{
		cout << "Stack is not empty \n";
	}
}

void Stack::Display(){
	for(int i=0;i<=top;i++){
		cout << array[i]<<" ";
	}
	cout <<endl;
}

int main(){
	Stack st;
	
	st.push(98);
	st.push(22);
	st.push(33);
	st.push(44);
	st.push(55);
	st.push(66);
	st.push(77);
	st.push(88);
	st.push(99);
	st.push(15);
	st.push(75);
	
	st.Display();
	
	cout << "Popped" <<st.pop()<<endl;
	cout << "Popped" <<st.pop()<<endl;
	
	st.Display();
}

