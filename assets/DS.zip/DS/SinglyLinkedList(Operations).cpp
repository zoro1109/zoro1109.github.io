#include <stdio.h>
#include <stdlib.h>
struct Node
{
    int data;
    struct Node *next;
};
struct Node *head = NULL;
void insertAtBeginning(int value);
void insertAtEnd(int value);
void insertBetween(int value, int loc1, int loc2);
void display();
void removeBeginning();
void removeEnd();
void removeSpecific(int delValue);

int main()
{
    int choice, value, choice1, loc1, loc2;
    while (1)
    {
        printf("\n\n****** MENU ******\n1. Insert\n2. Show\n3. Delete\n4. Exit\nEnter your choice:");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            printf("Insert the value to insert:");
            scanf("%d", &value);
            while (1)
            {
                printf("Where do you want to insert:\n1. At the beginning\n2. At the end\n3. Between\nPlease enter your choice:");
                scanf("%d", &choice1);
                switch (choice1)
                {
                case 1:
                    insertAtBeginning(value);
                    break;
                case 2:
                    insertAtEnd(value);
                    break;
                case 3:
                    printf("Insert the two values where you want to insert:");
                    scanf("%d%d", &loc1, &loc2);
                    insertBetween(value, loc1, loc2);
                    break;
                default:
                    printf("\nIncorrect entry! Try again!\n\n");
                    break;
                }
                break;
            }
            break;
        case 2:
            display();
            break;
        case 3:
            printf("How do you want to remove:\n1. From the beginning\n2. From the end\n3. Specific\nPlease enter your choice:");
            scanf("%d", &choice1);
            switch (choice1)
            {
            case 1:
                removeBeginning();
                break;
            case 2:
                removeEnd();
                break;
            case 3:
                printf("Enter the value you want to remove:");
                scanf("%d", &loc2);
                removeSpecific(loc2);
                break;
            default:
                printf("\nIncorrect entry! Try again!\n\n");
                break;
            }
            break;
        case 4:
            exit(0);
        default:
            printf("\nIncorrect entry!!! Try again!!\n\n");
            break;
        }
    }
    return 0;
}
void insertAtBeginning(int value)
{
    struct Node *newNode;
    newNode = (struct Node *)malloc(sizeof(struct Node));
    newNode->data = value;
    if (head == NULL)
    {
        newNode->next = NULL;
        head = newNode;
    }
    else
    {
        newNode->next = head;
        head = newNode;
    }
    printf("\nA node inserted!!!\n");
}
void insertAtEnd(int value)
{
    struct Node *newNode;
    newNode = (struct Node *)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->next = NULL;
    if (head == NULL)
        head = newNode;
    else
    {
        struct Node *temp = head;
        while (temp->next != NULL)
            temp = temp->next;
        temp->next = newNode;
    }
    printf("\nA node inserted!!!\n");
}
void insertBetween(int value, int loc1, int loc2)
{
    struct Node *newNode;
    newNode = (struct Node *)malloc(sizeof(struct Node));
    newNode->data = value;
    if (head == NULL)
    {
        newNode->next = NULL;
        head = newNode;
    }
    else
    {
        struct Node *temp = head;
        while (temp->next != NULL && (temp->data != loc1 && temp->data != loc2))
        {
            temp = temp->next;
        }
        newNode->next = temp->next;
        temp->next = newNode;
    }
    printf("\nA node inserted!!!\n");
}
void removeBeginning()
{
    if (head == NULL)
        printf("\n\nThe list is empty!");
    else
    {
        struct Node *temp = head;
        if (head->next == NULL)
        {
            head = NULL;
            free(temp);
        }
        else
        {
            head = temp->next;
            free(temp);
        }
        printf("\nA node removed!!!\n\n");
    }
}
void removeEnd()
{
    if (head == NULL)
        printf("\nThe list is empty!\n");
    else
    {
        struct Node *temp1 = head, *temp2 = NULL;
        if (head->next == NULL)
        {
            head = NULL;
            free(temp1);
        }
        else
        {
            while (temp1->next != NULL)
            {
                temp2 = temp1;
                temp1 = temp1->next;
            }
            temp2->next = NULL;
            free(temp1);
        }
        printf("\nA node removed!!!\n\n");
    }
}
void removeSpecific(int delValue)
{
    struct Node *temp1 = head, *temp2 = NULL;

    while (temp1 != NULL && temp1->data != delValue)
    {
        temp2 = temp1;
        temp1 = temp1->next;
    }
    if (temp1 != NULL)
    {
        if (temp2 == NULL)
        {
            head = temp1->next;
        }
        else
        {
            temp2->next = temp1->next;
        }
        free(temp1);
        printf("\nA node removed!!!\n\n");
    }
    else
    {
        printf("\nNo nodes found in the list with value %d!\n\n", delValue);
    }
}
void display()
{
    if (head == NULL)
    {
        printf("\nThe list is empty\n");
    }
    else
    {
        struct Node *temp = head;
        printf("\n\nThe elements of the list are -\n");
        while (temp->next != NULL)
        {
            printf("%d ---> ", temp->data);
            temp = temp->next;
        }
        printf("%d ---> NULL\n\n", temp->data);
    }
}

