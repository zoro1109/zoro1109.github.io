#include <iostream>
using namespace std;
int search(int arr[], int n, int val)
{
int i;
 for (i = 0; i < n; i++){
 	if (arr[i] == val)
	 return i+1;	
 }
return -1;
}

int main()
{
 int arr[] = { 69,21,3,11,99,2,14,10, 40 };
 int val = 10;
 int n = sizeof(arr) / sizeof(arr[0]);
 int result = search(arr, n, val);
 cout<<"The elements of the array are:";
 for (int i=0;i<n;i++)
 cout<<arr[i]<<" ";
cout << "\nElement to be search is: "<<val;
if (result== -1)
  cout << "Element is not present in the array; ";
  else
  cout << "\nElement is present at "<< result<<" position of array; ";

 return 0;
}

