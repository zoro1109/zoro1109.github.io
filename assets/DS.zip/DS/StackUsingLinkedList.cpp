#include<iostream>
using namespace std;
class node{
    public:
        int data;
        node *next;
};

class Stack{
    private:
        node * top;
        public:
            Stack(){
                top=NULL;}
                void push(int x);
                int pop();
                void display();
                };
void Stack::push(int x)
{
    node *t=new node;
    if (t==NULL)
        cout<<"stack is full\n";
        else{
            t->data=x;
            t->next=top;
            top=t;
            cout<<x<<" is pushed"<<endl;
            }
}

int Stack::pop()
{
    int x= -1;
    
     if (top==NULL)
        cout<<"stack is Empty\n";
        else{
            x=top->data;
            node *t=top;
            top=top->next;
            delete t;
            }
            return x;
    
    }
    
    void Stack::display()
    {
        node*p=top;
        
        while(p!=NULL)
        {cout<<p->data<<" ";
        p=p->next;
            }
            cout<<endl;
    }
    
    
    int main()
    {Stack stk;
    
    stk.push(11);
    stk.push(12);
    stk.push(13);
    stk.push(14);
    stk.push(15);
    
    stk.display();
    
    cout<<stk.pop()<<" is popped\n";
    stk.display();
    return 0;
        }

