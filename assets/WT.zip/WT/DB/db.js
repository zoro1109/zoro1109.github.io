var mysql = require('mysql');
var http = require('http');

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "other"
});

con.connect(function (err) {
    if (err) {
        throw err;
    }
    console.log("Database connected");

    var sql = "CALL `delete_data`('sss')";
    con.query(sql, function (err) {
        if (err) throw err;
        console.log("1 Row Deleted!!");
        con.end();
    });
});
