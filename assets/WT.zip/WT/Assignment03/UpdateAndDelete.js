// Write a program to insert multiple students and also update and delete them wrt name.

var mysql = require("mysql");

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "company",
    port: 3306
});

function insert_multiple_emmploye() {
    con.connect((err) => {
        if (err) throw err;
        var emp_list = [
            ["abc", "abc@gmail.com", 1234567892, "Mumbai"],
            ["def", "def@gmail.com", 2345678913, "Mumbai"],
            ["ghi", "ghi@gmail.com", 6362678372, "Mumbai"],
        ];
        var stmt = "insert into employee values ?";
        con.query(stmt, [emp_list], (err, result) => {
            if (err) throw err;
            console.log(result);
        })
    })
}

function update_employee(address,name) {
    var sql = "update employee set address='" + address + "' where name='" + name + "';";
    con.query(sql, (err, result) => {
        if (err) throw err;
        console.log(result);
    })

}

function delete_employee(name) {
    var sql = "delete from employee where name='" + name + "';";
    con.query(sql, (err, result) => {
        if (err) throw err;
        console.log(result);
    })
}

//insert_multiple_emmploye();
update_employee("Pune","ghi");
//delete_employee("abc");
