var http = require("http");
var fs = require("fs");
var mysql = require("mysql");
var qs = require("querystring");
const { brotliCompressSync } = require("zlib");

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "company",
    port: 3306
});

var server =
    http.createServer((req, res) => {
        var body = "";
        if (req.method == 'GET') {
            res.writeHead(200, { "Content-Type": "html" });
            fs.createReadStream("C:/Users/Admin/Desktop/Abhishek/WT/Assignment03/Register.html").pipe(res);
        }
        else if (req.method = 'POST') {
            var formdata = "";
            req.on("data", (chunk) => {
                formdata += chunk;
                var data = qs.parse(formdata);
                body = "Name: " + data.uname + "\nEmail id: " + data.uemail + "\nPhone Number: " + data.uphone +
                    "\nAddress: " + data.uaddress;
                var contact = Number(data.uphone);

                con.connect((err) => {
                    if (err) throw err;
                    console.log("Connection successful");
    
                    var query = "insert into employee values('" + data.uname + "','"
                        + data.uemail + "'," + contact + ",'" + data.uaddress + "');";

                    con.query(query, (error, result) => {
                        if (error) throw err;

                        console.log(result);
                    });
                });
            });
        }

        req.on("end", () => {
            //res.writeHead(200,{"Content-Type":"text"});
            res.end(body);
        });
    });

server.listen(3500);
