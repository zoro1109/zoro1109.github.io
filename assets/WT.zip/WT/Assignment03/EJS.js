//3. Write a program to display data of students.
//A. Create a file to fetch data and render html content
//B. Create ejs file to display data


//npm install express
//npm install ejs

var mysql = require('mysql');
var express = require('express');
var ejs = require('ejs');

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "company",
    port: 3306,
});

var app = express();
app.set('view engine', 'ejs');
app.get("/data", (req, res, next) => {

    con.connect(function (err) {
        if (err) throw err;
        var sql = "select * from employee";
        
        con.query(sql, function (err, data, fields) {
            if (err) throw err;
            res.render("C:/Users/Admin/Desktop/Abhishek/WT/Assignment03/EJS.html", (title = "Employee List", empData = data));
        });
    })
});
app.listen(1000);
