var mysql = require("mysql");
var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "company",
});

//con.connect(function (err) {
//    if (err) throw err;
 //   var sql = "CREATE DATABASE Student";
 //   con.query(sql, function (err, result) {
 //       if (err) throw err;
 //       console.log("Database Created");
  //  });
//});

con.connect((err)=> {
    if(err){
        console.warn("Error");
    }
    else{
        console.warn("Connected");
    }
});