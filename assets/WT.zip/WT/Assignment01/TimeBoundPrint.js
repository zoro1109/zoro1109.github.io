function printfunction(){
    console.log("Hello");
    }
    setTimeout(printfunction, 5000);
    setTimeout(printfunction, 7000);