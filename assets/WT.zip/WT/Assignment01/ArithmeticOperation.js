var ex = require('./ExportArthOp');
console.log("Addition : " +ex.add(15,3));
console.log("Subtraction : " +ex.sub(15,3));
console.log("Multiplication : " +ex.mul(15,3));
console.log("division : " +ex.div(15,3));