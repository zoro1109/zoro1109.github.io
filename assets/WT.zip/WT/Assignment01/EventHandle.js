var emitter = require('events').EventEmitter;
var em = new emitter();
em.addListener("Event1",function(data){
console.log("Event1 : "+data);
});
em.on("Event2",function(data){
console.log("Event2 : "+data);
});
em.emit("Event1", "First event raised");
em.emit("Event2", "Second event raised");