var os = require('os');
console.log("Architecture : "+os.arch());
console.log("Free Memory : "+os.freemem());