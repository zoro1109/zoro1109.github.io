var emitter = require('events').EventEmitter;
var util = require('util');
function LoopProcessor(num){
var me = this;
setTimeout(function(){

for(var i= 1; i<=num; i++){
me.emit("BeforeProcess", i);
console.log("Processing"+i);
me.emit("AfterProcess", i);
}
},2000);
}
util.inherits(LoopProcessor, emitter)
var lp = new LoopProcessor(3);
lp.on("BeforeProcess", function(data){
console.log("Before Processing", +data);
});
lp.on("AfterProcess", function(data){
console.log("After Processing", +data);
});