let timer;

setTimeout(function a() {
    console.log("Successfully Started Function 1, wait till its completed.....");
    timer = setTimeout(() => {
        console.log("Function 1 completed");
    }, 3000);
}, 2000);

setTimeout(function B() {
    clearTimeout(timer);
    console.log("Cancelled the execution of Function 1");
}, 3000);