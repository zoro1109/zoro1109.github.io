var emitter = require('events').EventEmitter;

function LoopProcessor(num) {
    var e = new emitter();
    setTimeout(function () {
        for (var i = 1; i <= num; i++) {
            e.emit("BeforeEvent", i);
            console.log("Processing" + i);
            e.emit("AfterEvent", i);
        }
    }, 2000);
    return e;
}
var lp = new LoopProcessor(3);
lp.on("BeforeEvent", function (data) {
    console.log("Before Processing", +data);
});
lp.on("AfterEvent", function (data) {
    console.log("After Processing", +data);
});