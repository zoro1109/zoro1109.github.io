var http = require('http');
var fs = require('fs');

var server=http.createServer(function(req,res)
{
    res.writeHead(200,
        {'Content-Type':'text/plain'})
    res.write("File data is shown below.. \n");
    var readstream= fs.createReadStream('C:/Users/Admin/Desktop/Abhishek/WT/Assignment02/data.txt')  
    readstream.pipe(res) 

});
server.listen(5000);
