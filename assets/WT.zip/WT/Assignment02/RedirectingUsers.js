//Write a program for redirecting users to different pages based on requested url.
//a. /dashboard should redirect to dashboard
//b. Any unknown url should respond with 404 not found


var http = require('http');
var server = http.createServer(
    function (req, res) {
        if (req.url == '/') {
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.write('<html><body><h1>This is Home Page</h1></body></html>');
            res.end();
        }
    
    else if (req.url == '/Student') {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.write('<html><body><h1>This is Student Page</h1></body></html>');
    res.end();
    }
    else if (req.url == '/Admin') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.write('<html><body><h1>This is admin Page</h1></body></html>');
        res.end();
    }
    else {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.write('<html><body><h1>Invalid input!</h1></body></html>');
        res.end();
    }
}
).listen(5000)
