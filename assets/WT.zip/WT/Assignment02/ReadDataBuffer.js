var fs =require('fs');
const { buffer } = require('stream/consumers');
fs.open('C:/Users/Admin/Desktop/Abhishek/WT/Assignment02/data.txt','r',function(err,fd)
{
    if(err)
    {
        return console.error(err);
    }
    var buffer = new Buffer(1024);
    fs.read(fd,buffer,0,buffer.length,0 //position from where the data should be read
        ,function(err,bytes)
    {
        if(err) throw err;
        if(bytes>0)
        {
            console.log(buffer.slice(0,bytes).toString());
        }
        
    });
    fs.close(fd,function(err)
        {
            if(err)throw err;
        });
});
