//Write a program to read data from a file and send it as a response to the client when the“data” event is triggered.

http = require("http");
fs = require("fs");
var qs = require("querystring");

var server = http.createServer((req, res) => {
  var body = "";

    if (req.method == "GET") {
        res.writeHead(200,{"Content-Type":"html"});
        fs.createReadStream("C:/Users/Admin/Desktop/Abhishek/WT/Assignment02/Register.html").pipe(res);
    } 
    else if (req.method == "POST") {
        var formdata = "";
        req.on("data", (chunk) => {
            formdata += chunk;
            data = qs.parse(formdata);
            body ="NAME" +data.uname +"EMAIL " +data.uemail +"ADDRESS" +data.uaddress;
    });
  }

  req.on("end",() => {
    res.writeHead(200,{"Content-Type":"text"});
    res.end(body);
  });
});
server.listen(7000);
