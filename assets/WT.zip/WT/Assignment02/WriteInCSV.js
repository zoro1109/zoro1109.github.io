const { readFile } = require('fs');

var fs =require('fs').promises

async function openfile()
{
    try
    {
        const csvHeaders = 'name,quantity,price'
        await fs.writeFile('C:/Users/Admin/Desktop/Abhishek/WT/Assignment02/groceries.csv',csvHeaders);
    }
    catch(error)
    {
        console.error(`Got an error trying to write to a file: ${error.message}`);
    }
}

async function addgroceryitems(name,quantity,price){
try{
    const item= `\n${name},${quantity},${price}`;
    await fs.writeFile('C:/Users/Admin/Desktop/Abhishek/WT/Assignment02/groceries.csv',item,
                        {flag:'a'});
}
catch(err)
{
    console.error(`Error is: ${err.message}`);
    
}
}
(async function(){
    await openfile();
    await addgroceryitems("Bread",2,100);
})();
