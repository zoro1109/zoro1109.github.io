var fs=require('fs')

var file_path = 'C:/Users/Admin/Desktop/Abhishek/WT/Assignment02/data.txt'

//Asyncronous
fs.readFile(file_path,function(err,data)
{
    if(err) throw err;
    console.log(data.toString());
});

//Syncronous
try
{
var data=fs.readFileSync(file_path,'utf8');
console.log("Sync : "+data);
}
catch(err)
{
    console.log(err)
}
