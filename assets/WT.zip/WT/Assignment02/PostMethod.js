//Write a program to display data entered in a form using the post method.
//a) use get to display the form
//b) use post to fetch data from form on submit button click.(Name , PhoneNo ,Address)
//c) display entered data.


var http = require('http');
var fs = require('fs');
var qs = require('querystring')

var server = http.createServer((req, res) => {
  var body = "";
  var url = req.url;

  if (req.method == "GET") {
    res.writeHead(200,{"Content-Type": "text/html"}); // Change content type to "text/html"
    fs.createReadStream("C:/Users/Admin/Desktop/Abhishek/WT/Assignment02/Register.html").pipe(res);
  }
  else if (req.method == "POST") {
    var formdata = "";
    req.on("data", (chunk) => {
      formdata += chunk;
    });

    req.on("end", () => {
      var data = qs.parse(formdata);
      body = "Name: " + data.uname + "\nEmail id: " + data.uemail + "\nPhone Numer: " +data.uphone+ "\nAddress: " + data.uaddress;

      res.writeHead(200,{"Content-Type": "text/plain"}); // Change content type to "text/plain"
      res.end(body);
    });
  }
});

server.listen(5406);
console.log("Server is listening at port 5406");
