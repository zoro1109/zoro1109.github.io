var http = require('http')
var fs=require('fs')

var server=http.createServer(function(req,res)
{
    res.writeHead(200,
        {'Content-Type':"html"});
    var readstream=fs.createReadStream('C:/Users/Admin/Desktop/Abhishek/WT/Assignment02/index.html');
    readstream.pipe(res);
});
server.listen(3000);
