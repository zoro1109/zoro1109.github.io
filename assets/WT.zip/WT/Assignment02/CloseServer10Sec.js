var http = require('http')
var fs=require('fs')

var server=http.createServer(function(req,res)
{
 res.writeHead(200,
    {'Content-Type':"html"});
      var readstream=fs.createReadStream('C:/Users/Admin/Desktop/Abhishek/WT/Assignment02/index.html');
        readstream.pipe(res);
});

setTimeout(function() {
  server.close();
},10000);

server.listen(9000);
