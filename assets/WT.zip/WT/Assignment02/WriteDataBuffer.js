var fs=require('fs');
fs.open('C:/Users/Admin/Desktop/Abhishek/WT/Assignment02/data.txt','a',function(err,fd)
{
    if(err) console.log(err)
    var buffr = new Buffer(" Hello Buffer");

    fs.write(fd,buffr,0,buffr.length,null,function(err,bytes)
    {
        if(err) console.log(err);
        if(bytes>0)
        {
            console.log("Wrote "+ bytes+ " bytes");
        }
     });
     fs.close(fd,function(err)
     {
        if(err) throw err;
     });
});
