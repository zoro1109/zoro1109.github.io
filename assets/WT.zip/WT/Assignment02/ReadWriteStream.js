var fs = require('fs')

var readstream = fs.createReadStream('C:/Users/Admin/Desktop/Abhishek/WT/Assignment02/data.txt')
var writestream = fs.createWriteStream('C:/Users/Admin/Desktop/Abhishek/WT/Assignment02/data2.txt');

readstream.on("data",function(filedata)
{
    console.log(filedata.toString());
    writestream.write(filedata)
});
