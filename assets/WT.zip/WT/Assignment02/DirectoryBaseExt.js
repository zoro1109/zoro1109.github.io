var path = require('path')

var file_path = 'C:/Users/Admin/Desktop/Abhishek/WT/Assignment01/ExportArthOp.js'
console.log("Directory name: "+path.dirname(file_path));
console.log("Base name: "+path.basename(file_path));
console.log("Extension: "+path.extname(file_path));

console.log(path.resolve('ExportArithOP.js'))
